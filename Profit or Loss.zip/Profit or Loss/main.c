#include <stdio.h>

int main() {
    float buyingPrice, sellingPrice;

    printf("Enter Buying Price: ");
    scanf("%f", &buyingPrice);

    printf("Enter Selling Price: ");
    scanf("%f", &sellingPrice);

    if (sellingPrice > buyingPrice) {
        printf("Profit = %.2f\n", sellingPrice - buyingPrice);
    }
    else if (buyingPrice > sellingPrice) {
        printf("Loss = %.2f\n", buyingPrice - sellingPrice);
    }
    else {
        printf("No Profit No Loss\n");
    }

    return 0;
}
